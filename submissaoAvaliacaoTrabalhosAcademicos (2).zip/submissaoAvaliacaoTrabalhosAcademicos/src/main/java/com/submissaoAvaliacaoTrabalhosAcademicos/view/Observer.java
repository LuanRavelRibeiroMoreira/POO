package com.submissaoAvaliacaoTrabalhosAcademicos.view;

public interface Observer {
    public void update();
}
