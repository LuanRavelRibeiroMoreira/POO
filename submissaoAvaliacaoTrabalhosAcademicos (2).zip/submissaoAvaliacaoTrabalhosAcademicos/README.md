# Sistema de Submissão e Avaliação de Trabalhos Acadêmicos.
Sistema de Submissão e Avaliação de Trabalhos Acadêmicos, a ideia é utilizar o padrão MVC na linguagem Java. 
